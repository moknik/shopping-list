/*!
 * UAF COMMERCIAL LICENSE
 * ----------------------
 * 1. PREAMBLE and Definitions
 *   1.1 These UAF Commercial License Terms ("UAF CLT") govern licensing of the Unicorn Application Framework (UAF).
 *     The Customer and Unicorn concluded an agreement for the provision of Solution that is using UAF or its parts
 *     (the "Agreement").
 *   1.2 The provisions of these UAF CLT shall govern the relationship between the Customer and Unicorn regarding
 *     the UAF License granted under the Agreement. For the avoidance of doubt, in case of any conflict between these
 *     UAF CLT and the Agreement, the provisions of the Agreement always prevail.
 *   1.3 The "UAF Components", and each of them individually as "UAF Component", shall mean the components of the Unicorn
 *     Application Framework, which are listed and described in the Attachment I to these UAF CLT.
 *   1.4 "UAF" shall mean the Unicorn Application Framework the scope of which is described in Attachment I, including all
 *     associated documentation and preparatory design materials, in particular blueprints, models, user manuals,
 *     training materials, comprehensive instructions and guidelines for drafting, production, operation and maintenance of
 *     software solutions, reference architecture, ready-made components and tools, use cases and tutorials.
 *   1.5 The "Knowledge Base" shall mean the online materials, internet fora and other resources made available by Unicorn
 *     online with regard to the UAF, intended for the broad customer and developer community.
 *   1.6 The "License" shall mean the binding terms and conditions for use of the UAF by the Customer. The License is
 *     described in Clause 2 and may be further specified or modified by the Agreement.
 *   1.7 The "Solution" shall mean any product or service developed under the Agreement using the UAF or any of
 *     UAF Components or its other parts, further specified in the Agreement.
 * 2. LICENSE GRANT
 *   2.1 The Customer shall be hereby granted a non-exclusive and non-transferable worldwide license to use the UAF for
 *     the purpose of the Solution described in the Agreement. For this purpose, the Customer shall be entitled to modify
 *     the UAF and create derivative works based on the UAF.
 *   2.2 The Customer is entitled to grant third parties a sub-license allowing them to use the UAF or any derivative works
 *     based on the UAF under commercial terms of its choice, provided that:
 *     2.2.1 use of the UAF and any derivative works based on the UAF by third parties is limited to testing, handover and
 *       operation of the Solution or its use as a service,
 *     2.2.2 third parties are not entitled to use the UAF or any derivative works based on the UAF independently of
 *       the Solution,
 *     2.2.3 third parties are not provided access to source code of the UAF unless such right is granted by the Agreement
 *       or if they conclude a commercial license agreement with Unicorn.
 *   2.3 The Solution or its parts based on the UAF shall bear a prominent copyright notice "Based on Unicorn Application
 *     Framework Copyright (c) Unicorn" integrated
 *     2.3.1 in the graphical user interface of the Solution or its relevant part or
 *     2.3.2 in accompanying file if the Solution or its relevant part do not have graphical user interface or
 *     2.3.3 in Solution's documentation.
 *   2.4 The License shall be valid for the whole duration of copyright to the UAF, unless other duration of the License is
 *     specified in the Agreement.
 *   2.5 The Customer is entitled to access the Knowledge Base only if expressly agreed in the Agreement.
 *   2.6 The Unicorn retains all rights to the UAF not covered by the provisions of this Clause 2. Unless explicitly
 *     permitted by applicable law, the Customer may not use the UAF in any other way than provided by the provisions of
 *     this Clause 2 and may not allow such use on its behalf by any of its employees or agents.
 *   2.7 The price for the License is included in the price stipulated in the Agreement.
 * 3. MODIFICATIONS
 *   3.1 The Customer explicitly acknowledges that the UAF is under continuous development and any UAF Component or other
 *     part of the UAF may be modified, replaced or removed by the Unicorn from the UAF in any of its future versions.
 *   3.2 This License covers also any new version of UAF if some parts of the UAF are modified or replaced.
 *   3.3 If any part of the UAF is removed by Unicorn in any of its future versions, the License for such version of
 *     the UAF is reduced appropriately and covers only the remaining parts of UAF. Sub-licenses previously granted to
 *     third parties in accordance with Clause 2.2 remain unaffected.
 * 4. THIRD PARTY LICENSE TERMS
 *   4.1 UAF is using third party software tools (the "Third Party Software") that is an integral part of the UAF. Some of
 *     these tools are free software or open-source SW.
 *   4.2 The list of Third Party Software used in the UAF including its license terms and authors is provided as part of
 *     Attachment I to these UAF CLT.
 *   4.3 For the use of the above mentioned Third Party Software, the Customer acknowledges its license terms referred to
 *     in Attachment I to these UAF CLT.
 * 5. NO TRADEMARK OR PATENT LICENSE
 *   5.1 These UAF CLT cover only copyright use of the UAF. If not expressly agreed otherwise, the Customer shall not be
 *     granted any trademark and/or patent license here under and nothing in these UAF CLT shall be interpreted in a way it
 *     does so.
 * 6. LIMITED WARRANTY
 *   6.1 IF NOT STIPULATED OTHER WISE OR REQUIRED BY APPLICABLE LAW, THE UAF IS PROVIDED ON "AS IS" BASIS,
 *     WITH NO WARRANTY OF, INCLUDING WITHOUT LIMITATION, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE ENTIRE
 *     RISK AS TO THE QUALITY AND PERFORMANCE OF THE UAF IS CARRIED SOLELY BY THE CUSTOMER, UNLESS OTHERWISE AGREED BETWEEN
 *     THE UNICORN AND THE CUSTOMER IN THE AGREEMENT.
 * 7. LIMITATION OF LIABILITY
 *   7.1 TO THE EXTENT PERMITTED BY APPLICABLE LAW, THE UNICORN WILL NOT BE HELD LIABLE FOR ANY DAMAGES CAUSED BY
 *     THE DISTRIBUTION OR USE OF THE UAF. THIS ALSO INCLUDES ANY CONSEQUENTIAL AND/OR INCIDENTAL DAMAGES, MONETARY OR NOT,
 *     THAT ARE CONNECTED WITH THE DISTRIBUTION OR USE OF THE UAF, UNLESS OTHERWISE AGREED BETWEEN THE UNICORN AND
 *     THE CUSTOMER IN THE AGREEMENT.
 * 8. THIRD PARTY CLAIMS
 *   8.1 The Unicorn will defend or settle, at its option and expense, any action brought against the Customer in a member
 *     state of the European Union which concerns an allegation that the UAF provided infringes a patent or copyright or
 *     misappropriates a trade secret in such jurisdiction. The Unicorn shall pay costs and damages finally awarded against
 *     the Customer that are attributable to such action. The Customer declares to understand and agrees that following
 *     conditions must be fulfilled in order to make Unicorn's obligations under this Clause 8 effective and enforceable:
 *     The Customer must (a) notify Unicorn promptly in writing of the action or any reasonable threat of it,
 *     (b) provide the Unicorn with all reasonable information and assistance it will request to settle or defend the action, and
 *     (c) grant the Unicorn sole authority and control of the defense or settlement of the action.
 *   8.2 If a claim is made under Clause 8.1 the Unicorn may, at its sole option and expense:
 *     (a) replace or modify the UAF so that it becomes non-infringing,
 *     (b) procure for the Customer the right to continue using the UAF unmodified.
 *   8.3 The Unicorn shall not be held liable to the Customer if the action is based on:
 *     (a) the combination of UAF with any product not provided by Unicorn,
 *     (b) the modification of the UAF other than by Unicorn,
 *     (c) the use of other than a current unaltered release of the UAF,
 *     (d) a product that the Customer makes, uses, or sells,
 *     (e) infringement by the Customer that is deemed willful. In the case under (e) the Customer shall reimburse
 *     the Unicorn for its reasonable attorney fees and other costs related to the action.
 *   8.4 THIS CLAUSE IS SUBJECT TO CLAUSE 7 AND STATES UNICORN'S ENTIRE LIABILITY, CUSTOMER'S SOLE AND EXCLUSIVE REMEDY,
 *     FOR DEFENSE, SETTLEMENT AND DAMAGES, WITH RESPECT TO ANY ALLEGED PATENT OR COPYRIGHT INFRINGEMENT OR TRADE SECRET
 *     MISAPPROPRIATION BY ANY ITEM PROVIDED UNDER THESE TERMS, UNLESS OTHERWISE AGREEMENT BETWEEN UNICORN AND THE CUSTOMER
 *     IN THE AGREEMENT.
 * 9. GENERAL PROVISIONS
 *   9.1 By entering into the Agreement, the Customer signifies its assent to and acceptance of these UAF CLT.
 *   9.2 The License is effective from the moment of execution of the Agreement, if the Agreement does not specify later
 *     date. Where the provisions of the Agreement regarding the License and provisions of these UAF CLT differ, provisions
 *     of the Agreement shall prevail.
 *   9.3 If any provision of the Agreement regarding the License or these UAF CLT is held by a court of competent
 *     jurisdiction to be void, invalid, unenforceable or illegal, such provision shall be severed from the Agreement or
 *     these UAF CLT and the remaining provisions will remain in full force and effect.
 *   9.4 The provisions of Clauses 7 and 8 shall survive any expiration or termination of the Agreement.
 *   9.5 All rights and obligations between the Unicorn and the Customer arising on the basis of these UAF CLT or
 *     in connection with them are governed by the laws of the Czech Republic with the exclusion of both the rules on
 *     the conflict of laws and the United Nations Convention on Contracts for the International Sale of Goods (CISG).
 *   9.6 The resolution of all disputes arising from or connected here to shall be under sole jurisdiction of the courts of
 *     the Czech Republic.
 */
!function(e,t){
"object"==typeof exports&&"object"==typeof module?module.exports=t(require("module"),require("uu5g05"),require("uu5g04"),require("uu5g05-elements"),require("uu_plus4u5g02"),require("uu_plus4u5g02-app"),require("uu_plus4u5g02-elements"),require("uu5g05-forms"),require("react")):"function"==typeof define&&define.amd?define("index",["module","uu5g05","uu5g04","uu5g05-elements","uu_plus4u5g02","uu_plus4u5g02-app","uu_plus4u5g02-elements","uu5g05-forms","react"],t):"object"==typeof exports?exports.index=t(require("module"),require("uu5g05"),require("uu5g04"),require("uu5g05-elements"),require("uu_plus4u5g02"),require("uu_plus4u5g02-app"),require("uu_plus4u5g02-elements"),require("uu5g05-forms"),require("react")):e.index=t(e[void 0],e.uu5g05,e.uu5g04,e["uu5g05-elements"],e.uu_plus4u5g02,e["uu_plus4u5g02-app"],e["uu_plus4u5g02-elements"],e["uu5g05-forms"],e.react)
}(this,((e,t,n,i,o,r,s,l,u)=>(()=>{var a,c,d,p={12:(e,t,n)=>{"use strict";n.d(t,{Z:()=>r});var i=n(94);const o="UuShopping.",r={TAG:o,
Css:i.Utils.Css.createCssModule(o.replace(/\.$/,"").toLowerCase().replace(/\./g,"-").replace(/[^a-z-]/g,""),"uu_shopping_maing01-hi/uu_shopping_maing01-hi@0.1.0")}},640:(e,t,n)=>{"use strict";n.d(t,{
Z:()=>s});var i=n(94),o=n(12);const r=o.Z.TAG+"Core.",s={...o.Z,TAG:r,
Css:i.Utils.Css.createCssModule(r.replace(/\.$/,"").toLowerCase().replace(/\./g,"-").replace(/[^a-z-]/g,""),"uu_shopping_maing01-hi/uu_shopping_maing01-hi@0.1.0")}},873:(e,t,n)=>{"use strict";n.d(t,{
Z:()=>c});var i=n(119),o=n.n(i),r=n(94),s=n(781),l=n.n(s),u=n(640),a=n(426);const c=(0,r.createVisualComponent)({uu5Tag:u.Z.TAG+"RouteBar",propTypes:{},defaultProps:{},render(e){const[,t]=(0,
r.useRoute)(),n=[{children:Uu5g05.Utils.Element.create(r.Lsi,{import:a.Z,path:["Menu","home"]}),onClick:()=>t("home")},{children:Uu5g05.Utils.Element.create(r.Lsi,{import:a.Z,path:["Menu","about"]}),
onClick:()=>t("about"),collapsed:!0}];return Uu5g05.Utils.Element.create(l().RouteBar,o()({appActionList:n},e))}})},184:(e,t,n)=>{"use strict";n.r(t),n.d(t,{render:()=>q})
;var i=n(602),o=n(94),r=(n(918),n(834)),s=n.n(r),l=n(763),u=n.n(l),a=n(781),c=n.n(a),d=n(640),p=(n(923),n(24)),m=n(12);const g=m.Z.TAG+"Bricks.",U={...m.Z,TAG:g,
Css:o.Utils.Css.createCssModule(g.replace(/\.$/,"").toLowerCase().replace(/\./g,"-").replace(/[^a-z-]/g,""),"uu_shopping_maing01-hi/uu_shopping_maing01-hi@0.1.0")},f=({screenSize:e})=>U.Css.css({
display:"flex",maxWidth:624,padding:"24px 0",margin:"0 auto",flexWrap:"wrap",..."xs"===e?{justifyContent:"center",textAlign:"center"}:null}),h=()=>U.Css.css({padding:"0 24px"
}),b=({screenSize:e})=>U.Css.css({flex:1,minWidth:"xs"===e?"100%":0});(0,o.createVisualComponent)({uu5Tag:U.TAG+"WelcomeRow",propTypes:{left:o.PropTypes.node},defaultProps:{left:void 0},render(e){
const{left:t,children:n}=e,[i]=(0,o.useScreenSize)(),r=o.Utils.VisualComponent.getAttrs(e,f({screenSize:i}));return Uu5g05.Utils.Element.create("div",r,Uu5g05.Utils.Element.create("div",{className:h({
screenSize:i})},t),Uu5g05.Utils.Element.create("div",{className:b({screenSize:i})},n))}});n(873),n(426);var v=n(119),E=n.n(v),k=n(389),y=n.n(k);const C=function(e){
return Uu5g05.Utils.Element.create(s().ListItem,{actionList:[{icon:"uugds-close",onClick:e.onDelete}]},Uu5g05.Utils.Element.create(s().Grid,{className:d.Z.Css.css({textAlign:"center",
display:"inline-block",width:"100%",margin:5,padding:30,border:"1px solid #ccc",borderRadius:"25px"})},Uu5g05.Utils.Element.create("div",{className:d.Z.Css.css({display:"inline-block",
borderRadius:"25px",fontSize:"1.5rem",fontType:"bold",color:"black",margin:10})},e.name),Uu5g05.Utils.Element.create(s().Button,{icon:"uugds-minus",onClick:e.downAmount,className:d.Z.Css.css({
display:"inline-block",borderRadius:"25px"})}),Uu5g05.Utils.Element.create("div",{className:d.Z.Css.css({display:"inline-block",fontSize:"1.5rem",margin:10})
},"Amount: ",e.amount),Uu5g05.Utils.Element.create(s().Button,{icon:"uugds-plus",onClick:e.upAmount,className:d.Z.Css.css({display:"inline-block",borderRadius:"25px"})
}),Uu5g05.Utils.Element.create(s().Box,{onClick:e.onChecked,className:d.Z.Css.css({display:"inline-block",paddingRight:"10px",borderRadius:"15px",marginLeft:20})
},Uu5g05.Utils.Element.create(y().Checkbox,{label:"Resolved",box:!1,value:e.resolved,borderRadius:"expressive"}))))},_=[{name:"apple",amount:5,id:o.Utils.String.generateId(),resolved:!1},{
name:"banana",amount:3,id:o.Utils.String.generateId(),resolved:!1},{name:"orange",amount:7,id:o.Utils.String.generateId(),resolved:!0},{name:"pear",amount:2,id:o.Utils.String.generateId(),resolved:!1
},{name:"pineapple",amount:1,id:o.Utils.String.generateId(),resolved:!0}];const x=function(e){const[t,n]=(0,o.useState)(_),[i,r]=(0,o.useState)(!1),l=()=>d.Z.Css.css({display:"inline-block",
maxWidth:"100%",backgroundColor:"#f5f5f5",padding:"32px",margin:"auto",width:700}),u=()=>d.Z.Css.css({margin:5}),a=o.Utils.VisualComponent.getAttrs(e,l()),c=o.Utils.VisualComponent.getAttrs(e,u())
;function p(e){n((([...t])=>{const n=t.findIndex((t=>t.id===e));return t.splice(n,1),console.log(e,t[n].name,"deleted"),t}))}function m(e){n((t=>{const n=[..._];switch(e){case"All":default:return n
;case"Resolved":return n.filter((e=>e.resolved));case"Unresolved":return n.filter((e=>!e.resolved))}}))}return Uu5g05.Utils.Element.create(s().Block,E()({},a,{header:"List of items to buy",
headerType:"title",actionList:[{icon:"mdi-plus",onClick:()=>r(!0)}]}),Uu5g05.Utils.Element.create(s().Button,E()({},c,{size:"l",icon:"mdi-circle-outline",onClick:()=>m("All")
}),"All"),Uu5g05.Utils.Element.create(s().Button,E()({},c,{size:"l",icon:"mdi-check-circle-outline",onClick:()=>m("Resolved")}),"Resolved"),Uu5g05.Utils.Element.create(s().Button,E()({},c,{size:"l",
icon:"mdi-close-circle-outline",onClick:()=>m("Unresolved")}),"Unresolved"),Uu5g05.Utils.Element.create(s().Grid,null,t.map((e=>Uu5g05.Utils.Element.create(C,E()({key:e.id},e,{onDelete:()=>p(e.id),
onChecked:()=>function(e){const t=e;n((n=>{const i=n.findIndex((t=>t.id===e)),o=[...n];return o[i]={...o[i],resolved:!o[i].resolved},console.log(t,o[i].name,"resolved:",o[i].resolved),o}))}(e.id),
upAmount:()=>{return t=e.id,void n((e=>{const n=e.findIndex((e=>e.id===t)),i=[...e];return i[n]={...i[n],amount:i[n].amount+1},console.log(t,i[n].name,i[n].amount),i}));var t},downAmount:()=>{
return t=e.id,void n((e=>{const n=e.findIndex((e=>e.id===t)),i=[...e];return 1===i[n].amount?p(t):i[n]={...i[n],amount:i[n].amount-1},console.log(t,i[n].name,i[n].amount),i}));var t}
}))))),Uu5g05.Utils.Element.create(y().Form.Provider,{key:i,onSubmit:function(e){const t=e.data.value;console.log(t),n((e=>[...e,{...t,id:o.Utils.String.generateId(),resolved:!1}])),r(!1)}
},Uu5g05.Utils.Element.create(s().Modal,{open:i,onClose:()=>r(!1),header:"Create item",
footer:Uu5g05.Utils.Element.create("div",null,Uu5g05.Utils.Element.create(y().CancelButton,null),Uu5g05.Utils.Element.create(y().SubmitButton,null))},Uu5g05.Utils.Element.create(y().FormText,{
label:"Name",name:"name",required:!0}),Uu5g05.Utils.Element.create(y().FormNumber,{label:"Amount",name:"amount",initialValue:1,required:!0,min:1}))))};var L=n(321);const w=function(e){const[t,n]=(0,
L.useState)(!1),[i,o]=(0,L.useState)(!1),[r,l]=(0,L.useState)(e.shoppingList),u=r.owner?[{icon:"uugds-richtext-toolbar",onClick:()=>n(!0)}]:[];return Uu5g05.Utils.Element.create(s().Block,{
actionList:u,className:d.Z.Css.css({width:400,maxWidth:"100%",backgroundColor:"#f5f5f5",padding:32,margin:"auto",borderRadius:"50px 50px 0 0 "})
},Uu5g05.Utils.Element.create(s().Grid,null,Uu5g05.Utils.Element.create("h1",null,r.name),r.owner?null:Uu5g05.Utils.Element.create("h2",null,"Owner: ",r.ownerName),r.owner?Uu5g05.Utils.Element.create(s().Button,{
size:"l",icon:"uugds-delete",onClick:()=>o(!0)},"Delete"):null,r.owner?Uu5g05.Utils.Element.create(s().Button,{size:"l",icon:"uugdsstencil-uiaction-archive",onClick:()=>{return e=r.id,
void console.log(e,"archived",r.name);var e}},"Archive"):null,r.owner?null:Uu5g05.Utils.Element.create(s().Button,{size:"l",icon:"uugds-log-out",onClick:()=>{return e=r.id,
void console.log(e,"leaved",r.name);var e}},"Leave list")),Uu5g05.Utils.Element.create(y().Form.Provider,{key:t,onSubmit:function(e){const t=e.data.value;console.log(t),l((e=>({...e,name:t.name}))),
n(!1)}},Uu5g05.Utils.Element.create(s().Modal,{open:t,onClose:()=>n(!1),header:"Rename list",
footer:Uu5g05.Utils.Element.create("div",null,Uu5g05.Utils.Element.create(y().CancelButton,null),Uu5g05.Utils.Element.create(y().SubmitButton,null))},Uu5g05.Utils.Element.create(y().FormText,{
label:"Name",name:"name",required:!0,initialValue:r.name}))),Uu5g05.Utils.Element.create(s().Modal,{open:i,onClose:()=>o(!1),header:"Delete list",footer:Uu5g05.Utils.Element.create("div",null)
},Uu5g05.Utils.Element.create(s().Block,null,"Are you sure you want to delete list ",Uu5g05.Utils.Element.create("b",null,r.name),"?",Uu5g05.Utils.Element.create("p",null,"This action cannot be undone. ")),Uu5g05.Utils.Element.create(s().Button,{
className:d.Z.Css.css({margin:5}),size:"l",icon:"uugds-delete",onClick:()=>{return e=r.id,void console.log(e,"deleted",r.name);var e}},"Delete"),Uu5g05.Utils.Element.create(s().Button,{
className:d.Z.Css.css({margin:5}),size:"l",icon:"uugds-cancel",onClick:()=>o(!1)},"Cancel")))};const S=function(e){const t=e.owner;return Uu5g05.Utils.Element.create(s().ListItem,{actionList:t?[{
icon:"uugds-close",onClick:e.onDelete}]:null},Uu5g05.Utils.Element.create(s().Grid,{className:d.Z.Css.css({textAlign:"center",display:"table-cell",width:"100%",margin:5,border:"1px solid #ccc",
borderRadius:"25px"})},Uu5g05.Utils.Element.create("h2",null,e.name)))};const A=function(e){const[t,n]=(0,o.useState)(e.userList),[i,r]=(0,o.useState)(e.shoppingList),[l,u]=(0,
o.useState)(t.filter((e=>i.userList.includes(e.id)))),[a,c]=(0,o.useState)(t.filter((e=>!i.userList.includes(e.id)))),[p,m]=(0,o.useState)(!1),g=i.owner?[{icon:"mdi-plus",onClick:()=>m(!0)
}]:[],U=()=>d.Z.Css.css({display:"inline-block",borderRadius:"0 0 50px 50px",backgroundColor:"#f5f5f5",padding:"32px",margin:"auto",width:300,maxWidth:"100%"
}),f=o.Utils.VisualComponent.getAttrs(e,U());return Uu5g05.Utils.Element.create(s().Block,E()({},f,{header:"List of users",headerType:"title",actionList:g
}),Uu5g05.Utils.Element.create(s().Grid,null,l.map((e=>Uu5g05.Utils.Element.create(S,E()({key:e.id},e,{owner:i.owner,onDelete:()=>function(e){const t=e;n((([...n])=>{const i=n.findIndex((t=>t.id===e))
;return l.splice(i,1),console.log(t,n[i].name,"deleted"),n}))}(e.id)}))))),Uu5g05.Utils.Element.create(y().Form.Provider,{key:p,onSubmit:function(e){
const n=Array.isArray(e.data.value.id)?e.data.value.id:[e.data.value.id];console.log(n),n.forEach((e=>{const n=t.find((t=>t.id===e));console.log(n.name,"added"),n&&u((e=>[...e,{id:n.id,name:n.name}]))
})),m(!1)}},Uu5g05.Utils.Element.create(s().Modal,{open:p,onClose:()=>m(!1),header:"Add user",
footer:Uu5g05.Utils.Element.create("div",null,Uu5g05.Utils.Element.create(y().CancelButton,null),Uu5g05.Utils.Element.create(y().SubmitButton,null))},Uu5g05.Utils.Element.create(y().FormSelect,{
itemList:a.map((e=>({value:e.id,children:e.name,icon:"uugdsstencil-user-account-solid"}))),label:"User",name:"id",required:!0,multiple:!0}))))},T={id:o.Utils.String.generateId(),name:"Fruit List",
archived:!1,owner:!0,ownerName:"John Connor",ItemList:[{name:"apple",amount:5,id:o.Utils.String.generateId(),resolved:!1},{name:"banana",amount:3,id:o.Utils.String.generateId(),resolved:!1},{
name:"orange",amount:7,id:o.Utils.String.generateId(),resolved:!0},{name:"pear",amount:2,id:o.Utils.String.generateId(),resolved:!1},{name:"pineapple",amount:1,id:o.Utils.String.generateId(),
resolved:!0}],userList:[1,2,3]},j=[{name:"John",id:1},{name:"Peter",id:2},{name:"Mary",id:3},{name:"Lucy",id:4},{name:"Tom",id:5},{name:"Bob",id:6}],B=()=>p.Z.Css.css({padding:32,margin:"auto",
backgroundColor:"#2194f3"});let z=(0,o.createVisualComponent)({uu5Tag:p.Z.TAG+"Home",propTypes:{},defaultProps:{},render(e){const{identity:t}=(0,
o.useSession)(),n=o.Utils.VisualComponent.getAttrs(e,B()),[i,r]=(0,L.useState)(T),[s,l]=(0,L.useState)(j);return Uu5g05.Utils.Element.create("div",n,Uu5g05.Utils.Element.create(w,{shoppingList:i
}),Uu5g05.Utils.Element.create("div",{style:{display:"flex",flexDirection:"row",flexWrap:"wrap",justifyContent:"space-between",backgroundColor:"#f5f5f5",borderRadius:"0 0 50px 50px"}
},Uu5g05.Utils.Element.create(x,{shoppingList:i}),Uu5g05.Utils.Element.create(A,{userList:s,shoppingList:i})))}});z=(0,a.withRoute)(z,{authenticated:!0})
;const P=z,O=o.Utils.Component.lazy((()=>n.e(701).then(n.bind(n,701)))),R=o.Utils.Component.lazy((()=>n.e(327).then(n.bind(n,327)))),Z=o.Utils.Component.lazy((()=>n.e(180).then(n.bind(n,180)))),I={
"":{redirect:"home"},home:e=>Uu5g05.Utils.Element.create(P,e),about:e=>Uu5g05.Utils.Element.create(O,e),"sys/uuAppWorkspace/initUve":e=>Uu5g05.Utils.Element.create(R,e),
controlPanel:e=>Uu5g05.Utils.Element.create(Z,e),"*":()=>Uu5g05.Utils.Element.create(s().Text,{category:"story",segment:"heading",type:"h1"},"Not Found")},N=(0,o.createVisualComponent)({
uu5Tag:d.Z.TAG+"Spa",propTypes:{},defaultProps:{},render:()=>Uu5g05.Utils.Element.create(u().SpaProvider,{initialLanguageList:["en","cs"]
},Uu5g05.Utils.Element.create(s().ModalBus,null,Uu5g05.Utils.Element.create(c().Spa,{routeMap:I})))});if(o.Environment.appVersion="0.1.0",!navigator.userAgent.match(/iPhone|iPad|iPod/)){
let e=document.createElement("link");e.rel="manifest",e.href="assets/manifest.json",document.head.appendChild(e)}let M;function q(e){M=e,
o.Utils.Dom.render(Uu5g05.Utils.Element.create(i.zj,null,Uu5g05.Utils.Element.create(N,null)),document.getElementById(e))}},426:(e,t,n)=>{"use strict";n.d(t,{Z:()=>l});var i=n(94),o=n(823)
;const r="uu_shopping_maing01-hi",s=e=>n(394)(`./${e}.json`);s.libraryCode=r,i.Utils.Lsi.setDefaultLsi(r,{en:o});const l=s},24:(e,t,n)=>{"use strict";n.d(t,{Z:()=>s});var i=n(94),o=n(12)
;const r=o.Z.TAG+"Routes.",s={...o.Z,TAG:r,
Css:i.Utils.Css.createCssModule(r.replace(/\.$/,"").toLowerCase().replace(/\./g,"-").replace(/[^a-z-]/g,""),"uu_shopping_maing01-hi/uu_shopping_maing01-hi@0.1.0")}},280:(e,t,n)=>{
var i=n(145),o="undefined"!=typeof document,r=((i?i.uri:o&&(document.currentScript||Array.prototype.slice.call(document.getElementsByTagName("script"),-1)[0]||{}).src)||"").toString(),s="/0.0.0/"
;(r=r.split(/\//).slice(0,-1).join("/")+"/").substr(-7)===s&&(r=r.substr(0,r.length-7)+"/0.1.0/"),n.p=r,e.exports=n(184);var l=e.exports
;l&&"object"==typeof l&&("version"in l||Object.defineProperty(l,"version",{configurable:!0,value:"0.1.0"}),"name"in l||Object.defineProperty(l,"name",{configurable:!0,
value:"uu_shopping_maing01-hi".split(/[\/\\]/).pop()}),"namespace"in l||Object.defineProperty(l,"namespace",{configurable:!0,value:"UuShopping"}))},602:(e,t,n)=>{"use strict"
;var i,o=(i=n(321))&&"object"==typeof i&&"default"in i?i.default:i;function r(e){return r.warnAboutHMRDisabled&&(r.warnAboutHMRDisabled=!0,
console.error("React-Hot-Loader: misconfiguration detected, using production version in non-production environment."),console.error("React-Hot-Loader: Hot Module Replacement is not enabled.")),
o.Children.only(e.children)}r.warnAboutHMRDisabled=!1;var s=function e(){return e.shouldWrapWithAppContainer?function(e){return function(t){return o.createElement(r,null,o.createElement(e,t))}
}:function(e){return e}};s.shouldWrapWithAppContainer=!1;t.zj=r},394:(e,t,n)=>{var i={"./cs.json":[27,27],"./en.json":[823]};function o(e){if(!n.o(i,e))return Promise.resolve().then((()=>{
var t=new Error("Cannot find module '"+e+"'");throw t.code="MODULE_NOT_FOUND",t}));var t=i[e],o=t[0];return Promise.all(t.slice(1).map(n.e)).then((()=>n.t(o,19)))}o.keys=()=>Object.keys(i),o.id=394,
e.exports=o},145:t=>{"use strict";t.exports=e},321:e=>{"use strict";e.exports=u},918:e=>{"use strict";e.exports=n},94:e=>{"use strict";e.exports=t},834:e=>{"use strict";e.exports=i},389:e=>{
"use strict";e.exports=l},763:e=>{"use strict";e.exports=o},781:e=>{"use strict";e.exports=r},923:e=>{"use strict";e.exports=s},119:e=>{function t(){
return e.exports=t=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var i in n)Object.prototype.hasOwnProperty.call(n,i)&&(e[i]=n[i])}return e
},e.exports.__esModule=!0,e.exports.default=e.exports,t.apply(this,arguments)}e.exports=t,e.exports.__esModule=!0,e.exports.default=e.exports},823:e=>{"use strict"
;e.exports=JSON.parse('{"appName":"Application uuShopping","About":{"header":"About application uuShopping","creatorsHeader":"Application creators","termsOfUse":"Terms of use"},"AboutContent":{"content":"<uu5string/>Demo application is a template for developing new applications.","technologiesContent":"<uu5string/>Other used technologies: <Uu5Elements.Link href=\'http://www.w3schools.com/html/default.asp\' target=\'_blank\'>Html5</Uu5Elements.Link>, <Uu5Elements.Link href=\'http://www.w3schools.com/css/default.asp\' target=\'_blank\'>CSS</Uu5Elements.Link>, <Uu5Elements.Link href=\'http://www.w3schools.com/js/default.asp\' target=\'_blank\'>JavaScript</Uu5Elements.Link>, <Uu5Elements.Link href=\'http://getbootstrap.com\' target=\'_blank\'>Bootstrap</Uu5Elements.Link>, <Uu5Elements.Link href=\'https://reactjs.org\' target=\'_blank\'>React</Uu5Elements.Link>, <Uu5Elements.Link href=\'https://www.ruby-lang.org\' target=\'_blank\'>Ruby</Uu5Elements.Link>, <Uu5Elements.Link href=\'http://puma.io\' target=\'_blank\'>Puma</Uu5Elements.Link> a <Uu5Elements.Link href=\'https://www.docker.com\' target=\'_blank\'>Docker</Uu5Elements.Link>. Application is operated in the <Uu5Elements.Link href=\'https://plus4u.net\' target=\'_blank\'>Plus4U</Uu5Elements.Link> internet service with the usage of <Uu5Elements.Link href=\'https://azure.microsoft.com\' target=\'_blank\'>Microsoft Azure</Uu5Elements.Link> cloud."},"ControlPanel":{"rightsError":"You do not have sufficient rights to display this component.","btNotConnected":"The application is not connected to a Business Territory."},"Home":{"welcome":"Welcome","intro":"<uu5string/>This template consist of prepared client and server side. Shown components demonstrate possibilities and way of using. For application developing purposes they are suitable for modifying, copying and deleting. More about uuApp Structure see documentation&nbsp; <Uu5Elements.Link href=\\"https://uuapp.plus4u.net/uu-bookkit-maing01/e884539c8511447a977c7ff070e7f2cf/book/page?code=stepByStepApp\\" target=\\"_blank\\">uuAppDevKit</Uu5Elements.Link>.","clientSide":"<uu5string/>Libraries <Uu5Elements.Link href=\\"https://uuapp.plus4u.net/uu-bookkit-maing01/05ecbf4e8bca405290b1a6d4cee8813a/book\\" target=\\"_blank\\">uu5</Uu5Elements.Link> and <Uu5Elements.Link href=\\"https://uuapp.plus4u.net/uu-bookkit-maing01/83c1406c4fc541dba975941424106318/book\\" target=\\"_blank\\">uuPlus4U5</Uu5Elements.Link> are used for developing of client side.","serverSide":"<uu5string/>It is necessary to initialize application workspace for running server side. See manual <Uu5Elements.Link href=\\"https://uuapp.plus4u.net/uu-bookkit-maing01/e884539c8511447a977c7ff070e7f2cf/book/page?code=stepByStepApp\\" target=\\"_blank\\">uuApp Template Developer Guide</Uu5Elements.Link>"},"InitAppWorkspace":{"notAuthorized":"You do not have sufficient rights to use the application.","formHeader":"Initialize uuApp","formHeaderInfo":"<uu5string/>Your uuApp is running, but requires initialization. If you need help with filling up this form, see\\n<Uu5Elements.Link target=\\"_blank\\" href=\\"#\\">Documentation</Uu5Elements.Link>.","notAuthorizedForInit":"The application is running but it was not initialized yet and you do not have sufficient rights to do so.","uuBtLocationUriLabel":"uuBusinessTerritory location","uuBtLocationUriInfo":"Uri of the uuBt location where AWSC will be created","nameLabel":"Name","initialize":"Initialize"},"Menu":{"home":"Welcome","about":"About Application"}}')
}},m={};function g(e){var t=m[e];if(void 0!==t)return t.exports;var n=m[e]={exports:{}};return p[e](n,n.exports,g),n.exports}return g.m=p,g.n=e=>{var t=e&&e.__esModule?()=>e.default:()=>e
;return g.d(t,{a:t}),t},c=Object.getPrototypeOf?e=>Object.getPrototypeOf(e):e=>e.__proto__,g.t=function(e,t){if(1&t&&(e=this(e)),8&t)return e;if("object"==typeof e&&e){if(4&t&&e.__esModule)return e
;if(16&t&&"function"==typeof e.then)return e}var n=Object.create(null);g.r(n);var i={};a=a||[null,c({}),c([]),c(c)]
;for(var o=2&t&&e;"object"==typeof o&&!~a.indexOf(o);o=c(o))Object.getOwnPropertyNames(o).forEach((t=>i[t]=()=>e[t]));return i.default=()=>e,g.d(n,i),n},g.d=(e,t)=>{
for(var n in t)g.o(t,n)&&!g.o(e,n)&&Object.defineProperty(e,n,{enumerable:!0,get:t[n]})},g.f={},g.e=e=>Promise.all(Object.keys(g.f).reduce(((t,n)=>(g.f[n](e,t),t)),[])),g.u=e=>"chunks/index/"+e+"-"+{
27:"49b2ba790d5203f14212",180:"c5174ccbcdd238580846",327:"ad392f4daae41cc803a6",701:"d67fcaedc1989450bd8f"}[e]+".min.js",g.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t),d={},g.l=(e,t,n,i)=>{
if(d[e])d[e].push(t);else{var o,r;if(void 0!==n)for(var s=document.getElementsByTagName("script"),l=0;l<s.length;l++){var u=s[l];if(u.getAttribute("src")==e){o=u;break}}o||(r=!0,
(o=document.createElement("script")).charset="utf-8",o.timeout=120,g.nc&&o.setAttribute("nonce",g.nc),o.src=e,0!==o.src.indexOf(window.location.origin+"/")&&(o.crossOrigin="anonymous")),d[e]=[t]
;var a=(t,n)=>{o.onerror=o.onload=null,clearTimeout(c);var i=d[e];if(delete d[e],o.parentNode&&o.parentNode.removeChild(o),i&&i.forEach((e=>e(n))),t)return t(n)},c=setTimeout(a.bind(null,void 0,{
type:"timeout",target:o}),12e4);o.onerror=a.bind(null,o.onerror),o.onload=a.bind(null,o.onload),r&&document.head.appendChild(o)}},g.r=e=>{
"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},g.p="",(()=>{var e={826:0};g.f.j=(t,n)=>{
var i=g.o(e,t)?e[t]:void 0;if(0!==i)if(i)n.push(i[2]);else{var o=new Promise(((n,o)=>i=e[t]=[n,o]));n.push(i[2]=o);var r=g.p+g.u(t),s=new Error;g.l(r,(n=>{if(g.o(e,t)&&(0!==(i=e[t])&&(e[t]=void 0),
i)){var o=n&&("load"===n.type?"missing":n.type),r=n&&n.target&&n.target.src;s.message="Loading chunk "+t+" failed.\n("+o+": "+r+")",s.name="ChunkLoadError",s.type=o,s.request=r,i[1](s)}
}),"chunk-"+t,t)}};var t=(t,n)=>{var i,o,[r,s,l]=n,u=0;if(r.some((t=>0!==e[t]))){for(i in s)g.o(s,i)&&(g.m[i]=s[i]);if(l)l(g)}for(t&&t(n);u<r.length;u++)o=r[u],g.o(e,o)&&e[o]&&e[o][0](),e[o]=0
},n=this.__webpack_jsonp_uu_shopping_maing01_hi_0_1_0_index=this.__webpack_jsonp_uu_shopping_maing01_hi_0_1_0_index||[];n.forEach(t.bind(null,0)),n.push=t.bind(null,n.push.bind(n))})(),g(280)})()));