/*!
 * UAF COMMERCIAL LICENSE
 * ----------------------
 * 1. PREAMBLE and Definitions
 *   1.1 These UAF Commercial License Terms ("UAF CLT") govern licensing of the Unicorn Application Framework (UAF).
 *     The Customer and Unicorn concluded an agreement for the provision of Solution that is using UAF or its parts
 *     (the "Agreement").
 *   1.2 The provisions of these UAF CLT shall govern the relationship between the Customer and Unicorn regarding
 *     the UAF License granted under the Agreement. For the avoidance of doubt, in case of any conflict between these
 *     UAF CLT and the Agreement, the provisions of the Agreement always prevail.
 *   1.3 The "UAF Components", and each of them individually as "UAF Component", shall mean the components of the Unicorn
 *     Application Framework, which are listed and described in the Attachment I to these UAF CLT.
 *   1.4 "UAF" shall mean the Unicorn Application Framework the scope of which is described in Attachment I, including all
 *     associated documentation and preparatory design materials, in particular blueprints, models, user manuals,
 *     training materials, comprehensive instructions and guidelines for drafting, production, operation and maintenance of
 *     software solutions, reference architecture, ready-made components and tools, use cases and tutorials.
 *   1.5 The "Knowledge Base" shall mean the online materials, internet fora and other resources made available by Unicorn
 *     online with regard to the UAF, intended for the broad customer and developer community.
 *   1.6 The "License" shall mean the binding terms and conditions for use of the UAF by the Customer. The License is
 *     described in Clause 2 and may be further specified or modified by the Agreement.
 *   1.7 The "Solution" shall mean any product or service developed under the Agreement using the UAF or any of
 *     UAF Components or its other parts, further specified in the Agreement.
 * 2. LICENSE GRANT
 *   2.1 The Customer shall be hereby granted a non-exclusive and non-transferable worldwide license to use the UAF for
 *     the purpose of the Solution described in the Agreement. For this purpose, the Customer shall be entitled to modify
 *     the UAF and create derivative works based on the UAF.
 *   2.2 The Customer is entitled to grant third parties a sub-license allowing them to use the UAF or any derivative works
 *     based on the UAF under commercial terms of its choice, provided that:
 *     2.2.1 use of the UAF and any derivative works based on the UAF by third parties is limited to testing, handover and
 *       operation of the Solution or its use as a service,
 *     2.2.2 third parties are not entitled to use the UAF or any derivative works based on the UAF independently of
 *       the Solution,
 *     2.2.3 third parties are not provided access to source code of the UAF unless such right is granted by the Agreement
 *       or if they conclude a commercial license agreement with Unicorn.
 *   2.3 The Solution or its parts based on the UAF shall bear a prominent copyright notice "Based on Unicorn Application
 *     Framework Copyright (c) Unicorn" integrated
 *     2.3.1 in the graphical user interface of the Solution or its relevant part or
 *     2.3.2 in accompanying file if the Solution or its relevant part do not have graphical user interface or
 *     2.3.3 in Solution's documentation.
 *   2.4 The License shall be valid for the whole duration of copyright to the UAF, unless other duration of the License is
 *     specified in the Agreement.
 *   2.5 The Customer is entitled to access the Knowledge Base only if expressly agreed in the Agreement.
 *   2.6 The Unicorn retains all rights to the UAF not covered by the provisions of this Clause 2. Unless explicitly
 *     permitted by applicable law, the Customer may not use the UAF in any other way than provided by the provisions of
 *     this Clause 2 and may not allow such use on its behalf by any of its employees or agents.
 *   2.7 The price for the License is included in the price stipulated in the Agreement.
 * 3. MODIFICATIONS
 *   3.1 The Customer explicitly acknowledges that the UAF is under continuous development and any UAF Component or other
 *     part of the UAF may be modified, replaced or removed by the Unicorn from the UAF in any of its future versions.
 *   3.2 This License covers also any new version of UAF if some parts of the UAF are modified or replaced.
 *   3.3 If any part of the UAF is removed by Unicorn in any of its future versions, the License for such version of
 *     the UAF is reduced appropriately and covers only the remaining parts of UAF. Sub-licenses previously granted to
 *     third parties in accordance with Clause 2.2 remain unaffected.
 * 4. THIRD PARTY LICENSE TERMS
 *   4.1 UAF is using third party software tools (the "Third Party Software") that is an integral part of the UAF. Some of
 *     these tools are free software or open-source SW.
 *   4.2 The list of Third Party Software used in the UAF including its license terms and authors is provided as part of
 *     Attachment I to these UAF CLT.
 *   4.3 For the use of the above mentioned Third Party Software, the Customer acknowledges its license terms referred to
 *     in Attachment I to these UAF CLT.
 * 5. NO TRADEMARK OR PATENT LICENSE
 *   5.1 These UAF CLT cover only copyright use of the UAF. If not expressly agreed otherwise, the Customer shall not be
 *     granted any trademark and/or patent license here under and nothing in these UAF CLT shall be interpreted in a way it
 *     does so.
 * 6. LIMITED WARRANTY
 *   6.1 IF NOT STIPULATED OTHER WISE OR REQUIRED BY APPLICABLE LAW, THE UAF IS PROVIDED ON "AS IS" BASIS,
 *     WITH NO WARRANTY OF, INCLUDING WITHOUT LIMITATION, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE ENTIRE
 *     RISK AS TO THE QUALITY AND PERFORMANCE OF THE UAF IS CARRIED SOLELY BY THE CUSTOMER, UNLESS OTHERWISE AGREED BETWEEN
 *     THE UNICORN AND THE CUSTOMER IN THE AGREEMENT.
 * 7. LIMITATION OF LIABILITY
 *   7.1 TO THE EXTENT PERMITTED BY APPLICABLE LAW, THE UNICORN WILL NOT BE HELD LIABLE FOR ANY DAMAGES CAUSED BY
 *     THE DISTRIBUTION OR USE OF THE UAF. THIS ALSO INCLUDES ANY CONSEQUENTIAL AND/OR INCIDENTAL DAMAGES, MONETARY OR NOT,
 *     THAT ARE CONNECTED WITH THE DISTRIBUTION OR USE OF THE UAF, UNLESS OTHERWISE AGREED BETWEEN THE UNICORN AND
 *     THE CUSTOMER IN THE AGREEMENT.
 * 8. THIRD PARTY CLAIMS
 *   8.1 The Unicorn will defend or settle, at its option and expense, any action brought against the Customer in a member
 *     state of the European Union which concerns an allegation that the UAF provided infringes a patent or copyright or
 *     misappropriates a trade secret in such jurisdiction. The Unicorn shall pay costs and damages finally awarded against
 *     the Customer that are attributable to such action. The Customer declares to understand and agrees that following
 *     conditions must be fulfilled in order to make Unicorn's obligations under this Clause 8 effective and enforceable:
 *     The Customer must (a) notify Unicorn promptly in writing of the action or any reasonable threat of it,
 *     (b) provide the Unicorn with all reasonable information and assistance it will request to settle or defend the action, and
 *     (c) grant the Unicorn sole authority and control of the defense or settlement of the action.
 *   8.2 If a claim is made under Clause 8.1 the Unicorn may, at its sole option and expense:
 *     (a) replace or modify the UAF so that it becomes non-infringing,
 *     (b) procure for the Customer the right to continue using the UAF unmodified.
 *   8.3 The Unicorn shall not be held liable to the Customer if the action is based on:
 *     (a) the combination of UAF with any product not provided by Unicorn,
 *     (b) the modification of the UAF other than by Unicorn,
 *     (c) the use of other than a current unaltered release of the UAF,
 *     (d) a product that the Customer makes, uses, or sells,
 *     (e) infringement by the Customer that is deemed willful. In the case under (e) the Customer shall reimburse
 *     the Unicorn for its reasonable attorney fees and other costs related to the action.
 *   8.4 THIS CLAUSE IS SUBJECT TO CLAUSE 7 AND STATES UNICORN'S ENTIRE LIABILITY, CUSTOMER'S SOLE AND EXCLUSIVE REMEDY,
 *     FOR DEFENSE, SETTLEMENT AND DAMAGES, WITH RESPECT TO ANY ALLEGED PATENT OR COPYRIGHT INFRINGEMENT OR TRADE SECRET
 *     MISAPPROPRIATION BY ANY ITEM PROVIDED UNDER THESE TERMS, UNLESS OTHERWISE AGREEMENT BETWEEN UNICORN AND THE CUSTOMER
 *     IN THE AGREEMENT.
 * 9. GENERAL PROVISIONS
 *   9.1 By entering into the Agreement, the Customer signifies its assent to and acceptance of these UAF CLT.
 *   9.2 The License is effective from the moment of execution of the Agreement, if the Agreement does not specify later
 *     date. Where the provisions of the Agreement regarding the License and provisions of these UAF CLT differ, provisions
 *     of the Agreement shall prevail.
 *   9.3 If any provision of the Agreement regarding the License or these UAF CLT is held by a court of competent
 *     jurisdiction to be void, invalid, unenforceable or illegal, such provision shall be severed from the Agreement or
 *     these UAF CLT and the remaining provisions will remain in full force and effect.
 *   9.4 The provisions of Clauses 7 and 8 shall survive any expiration or termination of the Agreement.
 *   9.5 All rights and obligations between the Unicorn and the Customer arising on the basis of these UAF CLT or
 *     in connection with them are governed by the laws of the Czech Republic with the exclusion of both the rules on
 *     the conflict of laws and the United Nations Convention on Contracts for the International Sale of Goods (CISG).
 *   9.6 The resolution of all disputes arising from or connected here to shall be under sole jurisdiction of the courts of
 *     the Czech Republic.
 */
!function(e,t){
"object"==typeof exports&&"object"==typeof module?module.exports=t(require("module"),require("uu5g05"),require("uu5g04"),require("uu5g05-elements"),require("uu_plus4u5g02"),require("uu_plus4u5g02-app"),require("uu5tilesg02-elements"),require("react"),require("uu5tilesg02"),require("uu5tilesg02-controls"),require("uu5g05-forms")):"function"==typeof define&&define.amd?define("index",["module","uu5g05","uu5g04","uu5g05-elements","uu_plus4u5g02","uu_plus4u5g02-app","uu5tilesg02-elements","react","uu5tilesg02","uu5tilesg02-controls","uu5g05-forms"],t):"object"==typeof exports?exports.index=t(require("module"),require("uu5g05"),require("uu5g04"),require("uu5g05-elements"),require("uu_plus4u5g02"),require("uu_plus4u5g02-app"),require("uu5tilesg02-elements"),require("react"),require("uu5tilesg02"),require("uu5tilesg02-controls"),require("uu5g05-forms")):e.index=t(e[void 0],e.uu5g05,e.uu5g04,e["uu5g05-elements"],e.uu_plus4u5g02,e["uu_plus4u5g02-app"],e["uu5tilesg02-elements"],e.react,e.uu5tilesg02,e["uu5tilesg02-controls"],e["uu5g05-forms"])
}(this,((e,t,n,i,a,r,s,l,o,u,c)=>(()=>{var d,m,g,p={899:(e,t,n)=>{"use strict";n.d(t,{Z:()=>l});var i=n(94),a=n(763),r=n.n(a);const s={call:async(e,t,n,i)=>(await r().Utils.AppClient[e](t,n,i)).data,
loadShoppingDetail(e){const t=s.getCommandUri("detail/"+e);return s.call("get",t)},loadShoppingList(e){const t=s.getCommandUri("shoppingList/list");return s.call("get",t)},createShoppingList(e){
console.log("call create",e);const t=s.getCommandUri("shoppingList/create");return s.call("post",t)},deleteShoppingList(e){console.log("call delete",e);const t=s.getCommandUri("shoppingList/delete")
;return s.call("post",t)},archiveShoppingList(e){console.log("call archive",e);const t=s.getCommandUri("shoppingList/archive");return s.call("post",t)},leaveShoppingList(e){console.log("call leave",e)
;const t=s.getCommandUri("shoppingList/leave");return s.call("post",t)},loadIdentityProfiles(){const e=s.getCommandUri("sys/uuAppWorkspace/initUve");return s.call("get",e)},initWorkspace(e){
const t=s.getCommandUri("sys/uuAppWorkspace/init");return s.call("post",t,e)},getWorkspace(){const e=s.getCommandUri("sys/uuAppWorkspace/get");return s.call("get",e)},
initAndGetWorkspace:async e=>(await s.initWorkspace(e),await s.getWorkspace()),getCommandUri:(e,t=i.Environment.appBaseUri)=>(t.endsWith("/")?t:t+"/")+(e.startsWith("/")?e.slice(1):e)},l=s},
12:(e,t,n)=>{"use strict";n.d(t,{Z:()=>r});var i=n(94);const a="UuShopping.",r={TAG:a,
Css:i.Utils.Css.createCssModule(a.replace(/\.$/,"").toLowerCase().replace(/\./g,"-").replace(/[^a-z-]/g,""),"uu_shopping_maing01-hi/uu_shopping_maing01-hi@0.1.0")}},640:(e,t,n)=>{"use strict";n.d(t,{
Z:()=>s});var i=n(94),a=n(12);const r=a.Z.TAG+"Core.",s={...a.Z,TAG:r,
Css:i.Utils.Css.createCssModule(r.replace(/\.$/,"").toLowerCase().replace(/\./g,"-").replace(/[^a-z-]/g,""),"uu_shopping_maing01-hi/uu_shopping_maing01-hi@0.1.0")}},261:(e,t,n)=>{"use strict";n.r(t),
n.d(t,{render:()=>Y});var i=n(602),a=n(94),r=(n(918),n(834)),s=n.n(r),l=n(763),o=n.n(l),u=n(781),c=n.n(u),d=n(640),m=n(24),g=n(899),p=n(12),U=n(119),h=n.n(U),f=n(320),v=n.n(f),b=n(321);const C=(0,
a.createVisualComponent)({uu5Tag:p.Z.TAG+"ListTile",propTypes:{},defaultProps:{},render(e){const t=()=>d.Z.Css.css({padding:32}),n=()=>d.Z.Css.css({marginLeft:10,marginBottom:10
}),i=a.Utils.VisualComponent.getAttrs(e,n()),[r,l]=(0,b.useState)(!1),[o,u]=(0,b.useState)(!1),c=(a.Utils.VisualComponent.getAttrs(e,t()),{
isAuthorized:UU5.Environment.getSession().getIdentity().uuIdentity===e.data.data.owner}),m=(()=>{const t=UU5.Environment.getSession().getIdentity().uuIdentity;let n=!1
;for(const i of e.data.data.user)if(i.includes(t)){n=!0;break}return{isAuthorized:n}})(),g=c.isAuthorized?e.data.data.name:`${e.data.data.name} - ${e.data.data.ownerName}`
;return e.data.handlerMap.delete,e.data.handlerMap.archive,e.data.handlerMap.leave,
c.isAuthorized||m.isAuthorized?Uu5g05.Utils.Element.create(Uu5g05.Fragment,null,Uu5g05.Utils.Element.create(s().Block,{className:d.Z.Css.css({borderStyle:"solid",borderWidth:.5,borderRadius:10,
borderColor:"#cccccc"})},Uu5g05.Utils.Element.create(s().Link,{href:"detail?id="+e.data.data.id},Uu5g05.Utils.Element.create(v().Tile,{header:g,onClick:()=>u(!0),className:d.Z.Css.css({padding:10,
margin:10,borderRadius:"10px",backgroundColor:e.data.data.archived?" #e6e6e6":c.isAuthorized?"#c3e2d0":"inherit"})
},45!=e.data.data.id?Uu5g05.Utils.Element.create(s().Block,null,Uu5g05.Utils.Element.create("ul",null,e.data.data.itemList.slice(0,3).map((e=>Uu5g05.Utils.Element.create("li",{key:e.id
},e.amount," ",e.name))),e.data.data.itemList.length>3&&Uu5g05.Utils.Element.create("div",null,"..."))):null)),c.isAuthorized?Uu5g05.Utils.Element.create(s().Button,h()({},i,{size:"l",
icon:"uugds-delete",onClick:()=>l(!0)}),"Delete"):null,c.isAuthorized?null:Uu5g05.Utils.Element.create(s().Button,h()({},i,{size:"l",icon:"uugds-log-out",onClick:()=>e.data.handlerMap.leave()
}),"Leave list"),c.isAuthorized&&!e.data.data.archived?Uu5g05.Utils.Element.create(s().Button,h()({},i,{size:"l",icon:"uugdsstencil-uiaction-archive",onClick:()=>e.data.handlerMap.archive(!0)
}),"Archive"):null,c.isAuthorized&&e.data.data.archived?Uu5g05.Utils.Element.create(s().Button,h()({top:!0},i,{size:"l",icon:"uugds-up",onClick:()=>e.data.handlerMap.archive(!1)
}),"Activate"):null),c.isAuthorized?Uu5g05.Utils.Element.create(s().Dialog,{open:r,onClose:()=>l(!1),header:"Are you sure you want to delete this shopping list? This action cannot be undone. ",
info:e.data.data.name,actionList:[{children:"Delete",icon:"mdi-delete",onClick:()=>e.data.handlerMap.delete(),significance:"highlighted",colorScheme:"negative"},{children:"Cancel",onClick:()=>l(!1)}]
}):null):null}});var E=n(767),y=n.n(E),k=n(190),x=n.n(k),L=n(389),A=n.n(L);const S=[{key:"archived",label:"Include archived",filter:(e,t)=>!!t||!e.data.archived,inputType:"bool"},{key:"owner",
label:"Only my lists",filter:(e,t)=>!t||e.data.owner===UU5.Environment.getSession().getIdentity().uuIdentity,inputType:"bool"}],w=()=>d.Z.Css.css({padding:32,margin:"auto"}),_=(0,
a.createVisualComponent)({uu5Tag:p.Z.TAG+"ShoppingListView",propTypes:{},defaultProps:{},render(e){const t=a.Utils.VisualComponent.getAttrs(e,w()),[n,i]=(0,b.useState)(!1),[r,l]=(0,b.useState)([])
;return Uu5g05.Utils.Element.create("div",t,Uu5g05.Utils.Element.create(y().ControllerProvider,{data:e.data,filterDefinitionList:S,filterList:r,onFilterChange:e=>l(e.data.filterList)
},Uu5g05.Utils.Element.create(s().Block,{actionList:[{component:Uu5g05.Utils.Element.create(x().FilterButton,{type:"bar"})},{icon:"uugds-plus",onClick:()=>i(!0)}]
},Uu5g05.Utils.Element.create(x().FilterBar,{initialExpanded:!0,displayClearButton:!1,displayCloseButton:!1,displayManagerButton:!1}),Uu5g05.Utils.Element.create(v().Grid,{tileMaxWidth:400,
tileMinWidth:200},C))),Uu5g05.Utils.Element.create(A().Form.Provider,{key:n,onSubmit:async t=>{await e.onCreate({id:a.Utils.String.generateId(),...t.data.value}),i(!1)}
},Uu5g05.Utils.Element.create(s().Modal,{open:n,onClose:()=>i(!1),header:"Create new shopping list",footer:Uu5g05.Utils.Element.create(A().SubmitButton,{content:"Create",colorSchema:"primary"})
},Uu5g05.Utils.Element.create(A().Form.View,{gridLayout:{xs:"name, ownerName,  owner",s:"name, ownerName, owner"}},Uu5g05.Utils.Element.create(A().FormText,{name:"name",label:"Name",required:!0
}),Uu5g05.Utils.Element.create(A().FormText,{name:"ownerName",label:"Owner Name",initialValue:UU5.Environment.getSession().getIdentity().name,readOnly:!0,colorScheme:"grey"
}),Uu5g05.Utils.Element.create(A().FormText,{name:"owner",label:"Owner ID",initialValue:UU5.Environment.getSession().getIdentity().uuIdentity,readOnly:!0,colorScheme:"grey"})))))}}),Z=(0,
a.createComponent)({uu5Tag:p.Z.TAG+"ShoppingListProvider",propTypes:{},defaultProps:{},render(e){const t=(0,a.useDataList)({handlerMap:{load:g.Z.loadShoppingList,create:g.Z.createShoppingList},
itemHandlerMap:{delete:g.Z.deleteShoppingList,archive:g.Z.archiveShoppingList,leave:g.Z.leaveShoppingList}});let n;switch(t.state){case"pendingNoData":n=Uu5g05.Utils.Element.create(s().Pending,{
size:"max"});break;case"errorNoData":n=Uu5g05.Utils.Element.create(s().Alert,{header:"Data about shopping lists cannot be loaded",priority:"error"});break;case"error":
n=Uu5g05.Utils.Element.create(s().Alert,{header:"Cannot create new shopping list",priority:"error"});break;default:n=Uu5g05.Utils.Element.create(_,{data:t.data,onCreate:t.handlerMap.create})}return n}
}),T=()=>m.Z.Css.css({padding:32,margin:"auto",backgroundColor:"#2194f3"});let B=(0,a.createVisualComponent)({uu5Tag:m.Z.TAG+"Home",propTypes:{},defaultProps:{},render(e){const{identity:t}=(0,
a.useSession)();a.Utils.VisualComponent.getAttrs(e,T());return Uu5g05.Utils.Element.create("div",null,Uu5g05.Utils.Element.create(Z,null))}});B=(0,u.withRoute)(B,{authenticated:!0});const z=B
;const P=function(e){return Uu5g05.Utils.Element.create(s().ListItem,{actionList:e.archived?null:[{icon:"uugds-close",onClick:e.onDelete}]},Uu5g05.Utils.Element.create(s().Grid,{
className:d.Z.Css.css({textAlign:"center",display:"inline-block",width:"100%",margin:5,padding:30,border:"1px solid #ccc",borderRadius:"25px"})},Uu5g05.Utils.Element.create("div",{
className:d.Z.Css.css({display:"inline-block",borderRadius:"25px",fontSize:"1.5rem",fontType:"bold",color:"black",margin:10})},e.name),e.archived?null:Uu5g05.Utils.Element.create(s().Button,{
icon:"uugds-minus",onClick:e.downAmount,className:d.Z.Css.css({display:"inline-block",borderRadius:"25px"})}),Uu5g05.Utils.Element.create("div",{className:d.Z.Css.css({display:"inline-block",
fontSize:"1.5rem",margin:10})},"Amount: ",e.amount),e.archived?null:Uu5g05.Utils.Element.create(s().Button,{icon:"uugds-plus",onClick:e.upAmount,className:d.Z.Css.css({display:"inline-block",
borderRadius:"25px"})}),e.archived?Uu5g05.Utils.Element.create(s().Box,{className:d.Z.Css.css({display:"inline-block",paddingRight:"10px",borderRadius:"15px",marginLeft:20})
},Uu5g05.Utils.Element.create(A().Checkbox,{label:"Resolved",disabled:!0,box:!1,value:e.resolved,borderRadius:"expressive"})):Uu5g05.Utils.Element.create(s().Box,{onClick:e.onChecked,
className:d.Z.Css.css({display:"inline-block",paddingRight:"10px",borderRadius:"15px",marginLeft:20})},Uu5g05.Utils.Element.create(A().Checkbox,{label:"Resolved",box:!1,value:e.resolved,
borderRadius:"expressive"}))))};const N=function(e){const[t,n]=(0,a.useState)([]);(0,b.useEffect)((()=>{n(e.itemList.itemList||[])}),[e.itemList.itemList]);const[i,r]=(0,
a.useState)(!1),l=()=>d.Z.Css.css({display:"inline-block",maxWidth:"100%",backgroundColor:"#f5f5f5",padding:"32px",margin:"auto",width:700}),o=()=>d.Z.Css.css({margin:5
}),u=a.Utils.VisualComponent.getAttrs(e,l()),c=a.Utils.VisualComponent.getAttrs(e,o());function m(e){n((([...t])=>{const n=t.findIndex((t=>t.id===e));return t.splice(n,1),
console.log(e,t[n].name,"deleted"),t}))}function g(t){n((n=>{const i=[...e.itemList.itemList];switch(t){case"All":default:return i;case"Resolved":return i.filter((e=>e.resolved));case"Unresolved":
return i.filter((e=>!e.resolved))}}))}return Uu5g05.Utils.Element.create(s().Block,h()({},u,{header:"List of items to buy",headerType:"title",actionList:e.itemList.archived?[]:[{icon:"mdi-plus",
onClick:()=>r(!0)}]}),Uu5g05.Utils.Element.create(s().Button,h()({},c,{size:"l",icon:"mdi-circle-outline",onClick:()=>g("All")}),"All"),Uu5g05.Utils.Element.create(s().Button,h()({},c,{size:"l",
icon:"mdi-check-circle-outline",onClick:()=>g("Resolved")}),"Resolved"),Uu5g05.Utils.Element.create(s().Button,h()({},c,{size:"l",icon:"mdi-close-circle-outline",onClick:()=>g("Unresolved")
}),"Unresolved"),Uu5g05.Utils.Element.create(s().Grid,null,t.map((t=>Uu5g05.Utils.Element.create(P,h()({key:t.id},t,{archived:e.itemList.archived,onDelete:()=>m(t.id),onChecked:()=>function(e){
const t=e;n((n=>{const i=n.findIndex((t=>t.id===e)),a=[...n];return a[i]={...a[i],resolved:!a[i].resolved},console.log(t,a[i].name,"resolved:",a[i].resolved),a}))}(t.id),upAmount:()=>{return e=t.id,
void n((t=>{const n=t.findIndex((t=>t.id===e)),i=[...t];return i[n]={...i[n],amount:i[n].amount+1},console.log(e,i[n].name,i[n].amount),i}));var e},downAmount:()=>{return e=t.id,void n((t=>{
const n=t.findIndex((t=>t.id===e)),i=[...t];return 1===i[n].amount?m(e):i[n]={...i[n],amount:i[n].amount-1},console.log(e,i[n].name,i[n].amount),i}));var e}
}))))),Uu5g05.Utils.Element.create(A().Form.Provider,{key:i,onSubmit:function(e){const t=e.data.value;console.log(t),n((e=>[...e,{...t,id:a.Utils.String.generateId(),resolved:!1}])),r(!1)}
},Uu5g05.Utils.Element.create(s().Modal,{open:i,onClose:()=>r(!1),header:"Create item",footer:Uu5g05.Utils.Element.create("div",null,Uu5g05.Utils.Element.create(A().CancelButton,{
className:d.Z.Css.css({margin:5}),onClick:()=>r(!1)}),Uu5g05.Utils.Element.create(A().SubmitButton,{className:d.Z.Css.css({margin:5})}))},Uu5g05.Utils.Element.create(A().Form.View,{gridLayout:{
xs:"name, amount",s:"name amount"}},Uu5g05.Utils.Element.create(A().FormText,{label:"Name",name:"name",required:!0}),Uu5g05.Utils.Element.create(A().FormNumber,{label:"Amount",name:"amount",
initialValue:1,required:!0,min:1})))))};const M=function(e){const[t,n]=(0,b.useState)(!1),[i,a]=(0,b.useState)(!1),[r,l]=(0,b.useState)(e.data),[o,u]=(0,b.useState)(!1);function c(e){
console.log(e,"archived",r.name)}const m=e.authenticated?[{icon:"uugds-richtext-toolbar",onClick:()=>n(!0)}]:[];return Uu5g05.Utils.Element.create(s().Block,{actionList:m,className:d.Z.Css.css({
width:400,maxWidth:"100%",backgroundColor:"#f5f5f5",padding:32,margin:"auto",borderRadius:"50px 50px 0 0 "})
},Uu5g05.Utils.Element.create(s().Grid,null,Uu5g05.Utils.Element.create("h1",null,r.name),e.authenticated?null:Uu5g05.Utils.Element.create("h2",null,"Owner: ",r.ownerName),e.authenticated?Uu5g05.Utils.Element.create(s().Button,{
size:"l",icon:"uugds-delete",onClick:()=>u(!0)},"Delete"):null,e.authenticated&&!r.archived?Uu5g05.Utils.Element.create(s().Button,{size:"l",icon:"uugdsstencil-uiaction-archive",onClick:()=>c(r.id)
},"Archive"):null,e.authenticated?null:Uu5g05.Utils.Element.create(s().Button,{size:"l",icon:"uugds-log-out",onClick:()=>{return e=r.id,void console.log(e,"leaved",r.name);var e}
},"Leave list"),e.authenticated&&r.archived?Uu5g05.Utils.Element.create(s().Button,{top:!0,size:"l",icon:"uugds-up",onClick:()=>c(r.id)
},"Activate"):null),e.authenticated?Uu5g05.Utils.Element.create(s().Dialog,{open:o,onClose:()=>u(!1),header:"Are you sure you want to delete this shopping list?",info:r.name,actionList:[{
children:"Delete",icon:"mdi-delete",onClick:()=>{return e=r.id,void console.log(e,"deleted",r.name);var e},significance:"highlighted",colorScheme:"negative"},{children:"Cancel",onClick:()=>u(!1)}]
}):null,Uu5g05.Utils.Element.create(A().Form.Provider,{key:t,onSubmit:function(e){const t=e.data.value;l((e=>({...e,name:t.name}))),n(!1)}},Uu5g05.Utils.Element.create(s().Modal,{open:t,
onClose:()=>n(!1),header:"Rename list",footer:Uu5g05.Utils.Element.create("div",null,Uu5g05.Utils.Element.create(A().CancelButton,{className:d.Z.Css.css({margin:5}),onClick:()=>n(!1)
}),Uu5g05.Utils.Element.create(A().SubmitButton,{className:d.Z.Css.css({margin:5})}))},Uu5g05.Utils.Element.create(A().FormText,{label:"Name",name:"name",required:!0,initialValue:r.name}))))}
;const R=function(e){return Uu5g05.Utils.Element.create(s().ListItem,{actionList:e.authenticated?[{icon:"uugds-close",onClick:e.onDelete}]:null},Uu5g05.Utils.Element.create(s().Grid,{
className:d.Z.Css.css({textAlign:"center",display:"table-cell",width:"100%",margin:5,border:"1px solid #ccc",borderRadius:"25px"})},Uu5g05.Utils.Element.create("h2",null,e.name)))}
;const j=function(e){const[t,n]=(0,a.useState)(e.userList),[i,r]=(0,a.useState)(e.shoppingList),[l,o]=(0,a.useState)(t.filter((e=>i.user.includes(e.id)))),[u,c]=(0,
a.useState)(t.filter((e=>!i.user.includes(e.id)))),[m,g]=(0,a.useState)(!1),p=e.authenticated?[{icon:"mdi-plus",onClick:()=>g(!0)}]:[],U=()=>d.Z.Css.css({display:"inline-block",
borderRadius:"0 0 50px 50px",backgroundColor:"#f5f5f5",padding:"32px",margin:"auto",width:300,maxWidth:"100%"}),f=a.Utils.VisualComponent.getAttrs(e,U())
;return Uu5g05.Utils.Element.create(s().Block,h()({},f,{header:"List of users",headerType:"title",actionList:p}),Uu5g05.Utils.Element.create(s().Grid,null,l.map((t=>Uu5g05.Utils.Element.create(R,h()({
key:t.id},t,{owner:i.owner,authenticated:e.authenticated,onDelete:()=>function(e){const t=e;n((([...n])=>{const i=n.findIndex((t=>t.id===e));return l.splice(i,1),console.log(t,n[i].name,"deleted"),n
}))}(t.id)}))))),Uu5g05.Utils.Element.create(A().Form.Provider,{key:m,onSubmit:function(e){const n=Array.isArray(e.data.value.id)?e.data.value.id:[e.data.value.id];console.log(n),n.forEach((e=>{
const n=t.find((t=>t.id===e));console.log(n.name,"added"),n&&o((e=>[...e,{id:n.id,name:n.name}]))})),g(!1)}},Uu5g05.Utils.Element.create(s().Modal,{open:m,onClose:()=>g(!1),header:"Add user",
footer:Uu5g05.Utils.Element.create("div",null,Uu5g05.Utils.Element.create(A().CancelButton,{className:d.Z.Css.css({margin:5}),onclick:()=>g(!1)}),Uu5g05.Utils.Element.create(A().SubmitButton,{
className:d.Z.Css.css({margin:5})}))},Uu5g05.Utils.Element.create(A().FormSelect,{itemList:u.map((e=>({value:e.id,children:e.name,icon:"uugdsstencil-user-account-solid"}))),label:"User",name:"id",
required:!0,multiple:!0}))))},O=[{name:"Tomáš Blažek",id:"9957-2503-7732-0000"},{name:"John Doe",id:"9957-2635-6563"},{name:"Mary",id:"9957-2503-7732-0003"},{name:"Lucy",id:"9957-2503-7732-003"},{
name:"Tom",id:5},{name:"Bob",id:6}],q=()=>m.Z.Css.css({padding:32,margin:"auto"});let D=(0,a.createVisualComponent)({uu5Tag:m.Z.TAG+"ShoppingList",propTypes:{},defaultProps:{},render(e){
const t=new URLSearchParams(window.location.search),{identity:n}=(0,a.useSession)(),i=(t.get("id"),a.Utils.VisualComponent.getAttrs(e,q())),[r,l]=(0,b.useState)(O),o={
isAuthorized:UU5.Environment.getSession().getIdentity().uuIdentity===e.data.owner},u=(()=>{const t=UU5.Environment.getSession().getIdentity().uuIdentity;let n=!1
;for(const i of e.data.user)if(i.includes(t)){n=!0;break}return{isAuthorized:n}})();return o.isAuthorized||u.isAuthorized?Uu5g05.Utils.Element.create("div",i,Uu5g05.Utils.Element.create(s().Link,{
href:"home"},Uu5g05.Utils.Element.create(s().Button,{size:"xl",icon:"uugds-home",onClick:!0})),Uu5g05.Utils.Element.create(M,{data:e.data,authenticated:o.isAuthorized
}),Uu5g05.Utils.Element.create("div",{style:{display:"flex",flexDirection:"row",flexWrap:"wrap",justifyContent:"space-between",backgroundColor:"#f5f5f5",borderRadius:"0 0 50px 50px"}
},Uu5g05.Utils.Element.create(N,{itemList:e.data}),Uu5g05.Utils.Element.create(j,{userList:r,shoppingList:e.data,authenticated:o.isAuthorized
}))):Uu5g05.Utils.Element.create(Uu5g05.Fragment,null,Uu5g05.Utils.Element.create(s().Alert,{header:"Forbidden access",priority:"error"}),Uu5g05.Utils.Element.create(s().Link,{href:"home"
},Uu5g05.Utils.Element.create(s().Button,{size:"xl",icon:"uugds-home",onClick:!0})))}});D=(0,u.withRoute)(D,{authenticated:!0});const I=D,V=(0,a.createComponent)({
uu5Tag:p.Z.TAG+"ShoppingListProvider",propTypes:{},defaultProps:{},render(e){const t=new URLSearchParams(window.location.search).get("id"),n=(0,a.useDataList)({handlerMap:{
load:()=>g.Z.loadShoppingDetail(t),create:g.Z.createShoppingList},itemHandlerMap:{delete:g.Z.deleteShoppingList,archive:g.Z.archiveShoppingList,leave:g.Z.leaveShoppingList}});let i
;switch(console.log("datalist",n),n.state){case"pendingNoData":i=Uu5g05.Utils.Element.create(s().Pending,{size:"max"});break;case"errorNoData":i=Uu5g05.Utils.Element.create(s().Alert,{
header:"Data about shopping lists cannot be loaded",priority:"error"});break;case"error":i=Uu5g05.Utils.Element.create(s().Alert,{header:"Cannot create new shopping list",priority:"error"});break
;default:i=Uu5g05.Utils.Element.create(I,{data:n.data[0].data,onCreate:n.handlerMap.create})}return i}}),W=()=>m.Z.Css.css({padding:32,margin:"auto"});let F=(0,a.createVisualComponent)({
uu5Tag:m.Z.TAG+"Home",propTypes:{},defaultProps:{},render(e){const{identity:t}=(0,a.useSession)();a.Utils.VisualComponent.getAttrs(e,W())
;return Uu5g05.Utils.Element.create("div",null,Uu5g05.Utils.Element.create(V,null))}});F=(0,u.withRoute)(F,{authenticated:!0})
;const G=F,H=a.Utils.Component.lazy((()=>n.e(701).then(n.bind(n,701)))),$=a.Utils.Component.lazy((()=>n.e(327).then(n.bind(n,327)))),J=a.Utils.Component.lazy((()=>n.e(180).then(n.bind(n,180)))),K={
"":{redirect:"home"},home:e=>Uu5g05.Utils.Element.create(z,e),detail:e=>Uu5g05.Utils.Element.create(G,e),detailList:e=>Uu5g05.Utils.Element.create(I,e),about:e=>Uu5g05.Utils.Element.create(H,e),
"sys/uuAppWorkspace/initUve":e=>Uu5g05.Utils.Element.create($,e),controlPanel:e=>Uu5g05.Utils.Element.create(J,e),"*":()=>Uu5g05.Utils.Element.create(s().Text,{category:"story",segment:"heading",
type:"h1"},"Not Found")},Q=(0,a.createVisualComponent)({uu5Tag:d.Z.TAG+"Spa",propTypes:{},defaultProps:{},render:()=>Uu5g05.Utils.Element.create(o().SpaProvider,{initialLanguageList:["en","cs"]
},Uu5g05.Utils.Element.create(s().ModalBus,null,Uu5g05.Utils.Element.create(c().Spa,{routeMap:K})))});if(a.Environment.appVersion="0.1.0",!navigator.userAgent.match(/iPhone|iPad|iPod/)){
let e=document.createElement("link");e.rel="manifest",e.href="assets/manifest.json",document.head.appendChild(e)}let X;function Y(e){X=e,
a.Utils.Dom.render(Uu5g05.Utils.Element.create(i.zj,null,Uu5g05.Utils.Element.create(Q,null)),document.getElementById(e))}},24:(e,t,n)=>{"use strict";n.d(t,{Z:()=>s});var i=n(94),a=n(12)
;const r=a.Z.TAG+"Routes.",s={...a.Z,TAG:r,
Css:i.Utils.Css.createCssModule(r.replace(/\.$/,"").toLowerCase().replace(/\./g,"-").replace(/[^a-z-]/g,""),"uu_shopping_maing01-hi/uu_shopping_maing01-hi@0.1.0")}},280:(e,t,n)=>{
var i=n(145),a="undefined"!=typeof document,r=((i?i.uri:a&&(document.currentScript||Array.prototype.slice.call(document.getElementsByTagName("script"),-1)[0]||{}).src)||"").toString(),s="/0.0.0/"
;(r=r.split(/\//).slice(0,-1).join("/")+"/").substr(-7)===s&&(r=r.substr(0,r.length-7)+"/0.1.0/"),n.p=r,e.exports=n(261);var l=e.exports
;l&&"object"==typeof l&&("version"in l||Object.defineProperty(l,"version",{configurable:!0,value:"0.1.0"}),"name"in l||Object.defineProperty(l,"name",{configurable:!0,
value:"uu_shopping_maing01-hi".split(/[\/\\]/).pop()}),"namespace"in l||Object.defineProperty(l,"namespace",{configurable:!0,value:"UuShopping"}))},602:(e,t,n)=>{"use strict"
;var i,a=(i=n(321))&&"object"==typeof i&&"default"in i?i.default:i;function r(e){return r.warnAboutHMRDisabled&&(r.warnAboutHMRDisabled=!0,
console.error("React-Hot-Loader: misconfiguration detected, using production version in non-production environment."),console.error("React-Hot-Loader: Hot Module Replacement is not enabled.")),
a.Children.only(e.children)}r.warnAboutHMRDisabled=!1;var s=function e(){return e.shouldWrapWithAppContainer?function(e){return function(t){return a.createElement(r,null,a.createElement(e,t))}
}:function(e){return e}};s.shouldWrapWithAppContainer=!1;t.zj=r},145:t=>{"use strict";t.exports=e},321:e=>{"use strict";e.exports=l},918:e=>{"use strict";e.exports=n},94:e=>{"use strict";e.exports=t},
834:e=>{"use strict";e.exports=i},389:e=>{"use strict";e.exports=c},767:e=>{"use strict";e.exports=o},190:e=>{"use strict";e.exports=u},320:e=>{"use strict";e.exports=s},763:e=>{"use strict"
;e.exports=a},781:e=>{"use strict";e.exports=r},119:e=>{function t(){return e.exports=t=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t]
;for(var i in n)Object.prototype.hasOwnProperty.call(n,i)&&(e[i]=n[i])}return e},e.exports.__esModule=!0,e.exports.default=e.exports,t.apply(this,arguments)}e.exports=t,e.exports.__esModule=!0,
e.exports.default=e.exports}},U={};function h(e){var t=U[e];if(void 0!==t)return t.exports;var n=U[e]={exports:{}};return p[e](n,n.exports,h),n.exports}return h.m=p,h.n=e=>{
var t=e&&e.__esModule?()=>e.default:()=>e;return h.d(t,{a:t}),t},m=Object.getPrototypeOf?e=>Object.getPrototypeOf(e):e=>e.__proto__,h.t=function(e,t){if(1&t&&(e=this(e)),8&t)return e
;if("object"==typeof e&&e){if(4&t&&e.__esModule)return e;if(16&t&&"function"==typeof e.then)return e}var n=Object.create(null);h.r(n);var i={};d=d||[null,m({}),m([]),m(m)]
;for(var a=2&t&&e;"object"==typeof a&&!~d.indexOf(a);a=m(a))Object.getOwnPropertyNames(a).forEach((t=>i[t]=()=>e[t]));return i.default=()=>e,h.d(n,i),n},h.d=(e,t)=>{
for(var n in t)h.o(t,n)&&!h.o(e,n)&&Object.defineProperty(e,n,{enumerable:!0,get:t[n]})},h.f={},h.e=e=>Promise.all(Object.keys(h.f).reduce(((t,n)=>(h.f[n](e,t),t)),[])),h.u=e=>"chunks/index/"+e+"-"+{
27:"49b2ba790d5203f14212",180:"7c5b7942c99c1876c4d5",327:"8a111f395a9a3ee26618",701:"c6cccaf59f3a50727525"}[e]+".min.js",h.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t),g={},h.l=(e,t,n,i)=>{
if(g[e])g[e].push(t);else{var a,r;if(void 0!==n)for(var s=document.getElementsByTagName("script"),l=0;l<s.length;l++){var o=s[l];if(o.getAttribute("src")==e){a=o;break}}a||(r=!0,
(a=document.createElement("script")).charset="utf-8",a.timeout=120,h.nc&&a.setAttribute("nonce",h.nc),a.src=e,0!==a.src.indexOf(window.location.origin+"/")&&(a.crossOrigin="anonymous")),g[e]=[t]
;var u=(t,n)=>{a.onerror=a.onload=null,clearTimeout(c);var i=g[e];if(delete g[e],a.parentNode&&a.parentNode.removeChild(a),i&&i.forEach((e=>e(n))),t)return t(n)},c=setTimeout(u.bind(null,void 0,{
type:"timeout",target:a}),12e4);a.onerror=u.bind(null,a.onerror),a.onload=u.bind(null,a.onload),r&&document.head.appendChild(a)}},h.r=e=>{
"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},h.p="",(()=>{var e={826:0};h.f.j=(t,n)=>{
var i=h.o(e,t)?e[t]:void 0;if(0!==i)if(i)n.push(i[2]);else{var a=new Promise(((n,a)=>i=e[t]=[n,a]));n.push(i[2]=a);var r=h.p+h.u(t),s=new Error;h.l(r,(n=>{if(h.o(e,t)&&(0!==(i=e[t])&&(e[t]=void 0),
i)){var a=n&&("load"===n.type?"missing":n.type),r=n&&n.target&&n.target.src;s.message="Loading chunk "+t+" failed.\n("+a+": "+r+")",s.name="ChunkLoadError",s.type=a,s.request=r,i[1](s)}
}),"chunk-"+t,t)}};var t=(t,n)=>{var i,a,[r,s,l]=n,o=0;if(r.some((t=>0!==e[t]))){for(i in s)h.o(s,i)&&(h.m[i]=s[i]);if(l)l(h)}for(t&&t(n);o<r.length;o++)a=r[o],h.o(e,a)&&e[a]&&e[a][0](),e[a]=0
},n=this.__webpack_jsonp_uu_shopping_maing01_hi_0_1_0_index=this.__webpack_jsonp_uu_shopping_maing01_hi_0_1_0_index||[];n.forEach(t.bind(null,0)),n.push=t.bind(null,n.push.bind(n))})(),h(280)})()));