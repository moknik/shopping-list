insomnia-workspace.json contains samples for testing commands from (https://insomnia.rest/) tool. 

Each command defined in this template has configured a "docs" page containing link to the command's documentation.
